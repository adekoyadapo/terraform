# Lambda to Cloudfunction
POC deploying functions to cloudfinction
## Todo
- integrate to pipeline
- test app deployment in pipeline
- document in TDD
- Add repo zip steps into pipeline